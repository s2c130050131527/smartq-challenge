Run command 

yarn start

or npm start


Features Implemented:

Fetch List of items
Search
Cart Using Redux
