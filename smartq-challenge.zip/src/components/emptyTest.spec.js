// Must have at least one test file in this directory or Mocha will throw an error.

describe('abc',() => {
    it('should be 5',() => {
        expect(2+3).toBe(5);

    })
})